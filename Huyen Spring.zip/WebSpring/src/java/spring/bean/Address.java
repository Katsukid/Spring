/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.bean;
import javax.inject.Named;
@Named("address")
public class Address {
    public String getQuan() {
        return quan;
    }
    public void setQuan(String quan) {
        this.quan = quan;
    }
    public String getPhuong() {
        return phuong;
    }
    public void setPhuong(String phuong) {
        this.phuong = phuong;
    }
    public String getThanhpho() {
        return thanhpho;
    }
    public void setThanhpho(String thanhpho) {
        this.thanhpho = thanhpho;
    }
    private String quan;
    private String phuong;
    private String thanhpho;
}
