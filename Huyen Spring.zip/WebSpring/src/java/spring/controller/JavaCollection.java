/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.controller;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 *
 * @author Katsukid
 */
public class JavaCollection {
    private List addressList;
    private Set addressSet;
    private Map addressMap;
    private Properties addressProp;
 
    public void setAddressList(List addressList) {
        this.addressList = addressList;
    }
    public List getAddressList() {
        return addressList;
    }
    public void setAddressSet(Set addressSet) {
        this.addressSet = addressSet;
    }
    public Set getAddressSet() {
        return addressSet;
    }
    public void setAddressMap(Map addressMap) {
        this.addressMap = addressMap;
    }
    public Map getAddressMap() {
        return addressMap;
    }
    public void setAddressProp(Properties addressProp) {
        this.addressProp = addressProp;
    }
    public Properties getAddressProp() {
        return addressProp;
    }
}
