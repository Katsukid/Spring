/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import spring.controller.JavaCollection;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.springframework.web.bind.annotation.PathVariable;
import spring.bean.Address;
import spring.bean.Student;
/**
 *
 * @author Katsukid
 */
@Controller
@RequestMapping(value="/hello")
public class HelloController {
    @RequestMapping(value="/xinchao", method=RequestMethod.GET)
    public String xinchao (ModelMap mv)
    {
         ApplicationContext context = 
                 new ClassPathXmlApplicationContext("hello.xml"); 
          Name obj = (Name) context.getBean("helloWorld"); 
       mv.put("applicationContext",  obj.getValue());
       
       
       // Name obja = (Name) context.getBean("helloWorld");
     //    obja.setValue("Gia tri moi");
    //  mv.put("applicationContext",  obj.getValue());
    //    Name objb = (Name) context.getBean("helloWorld");
           
   //  mv.put("applicationContext",  objb.getValue());
       return "xinchao";
    }
    @RequestMapping(value="/collection", method=RequestMethod.GET)
    public String JnjectionCollection (ModelMap mv)
    {
        ApplicationContext context = 
                 new ClassPathXmlApplicationContext("collection.xml");
        JavaCollection obj = (JavaCollection) context.getBean("javaCollection"); 
        List addressList = obj.getAddressList();
        Set addressSet = obj.getAddressSet();
        Map addressMap = obj.getAddressMap();
        Properties addressProp = obj.getAddressProp();
        mv.put("list", addressList);
        mv.put("set", addressSet);
        mv.put("map", addressMap);
        mv.put("prop", addressProp);
       return "collection";
    }
    @RequestMapping(value="/thong-tin", method=RequestMethod.GET)
    public String sinhvien (ModelMap mv)
    {
         ApplicationContext context = 
                 new ClassPathXmlApplicationContext("Bean.xml");
         Address add = (Address) context.getBean("address");
         add.setPhuong("Xuan Tao");
         add.setQuan("Bac Tu Liem");
         add.setThanhpho("Ha Noi");
         Student st1 = (Student) context.getBean("student");
         st1.setName("Hoang Lan");
         st1.setAddress(add);
          Student obj = (Student) context.getBean("student");
       mv.put("student",  obj);
       return "testBean";
    }
    @RequestMapping(value="/them-sinh-vien/{sinhvien}", method=RequestMethod.POST)
    public String name (@PathVariable("sinhvien")Student sinhvienStudent , ModelMap mv)
    {
         ApplicationContext context = 
                 new ClassPathXmlApplicationContext("Bean.xml");
         Address add = (Address) context.getBean("address");
         add.setPhuong("Xuan Tao");
         add.setQuan("Bac Tu Liem");
         add.setThanhpho("Ha Noi");
         Student st1 = (Student) context.getBean("student");
         st1.setName("Hoang Lan");
         //st1.setAddress(add);
          Student obj = (Student) context.getBean("student");
       mv.put("student",  obj);
       return "testBean";
    }
}
